module.exports = {
 'connection':{
  'host':'localhost',
  'user':'root',
  'password':''
 },
 'database':'news',
 'user_table':'admin'
}